#!/bin/bash

cd example && mvn clean install && java -jar target/client-example-0.1.1-jar-with-dependencies.jar

