package de.tu_dresden.selis;

import de.tu_dresden.selis.pubsub.*;
import de.tu_dresden.selis.pubsub.PubSubException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class Subscriber implements Runnable {

    int quality;

    int price;

    Logger LOG;

    public Subscriber(int quality, int price) {
        this.quality = quality;
        this.price = price;
    }

    @Override
    public void run() {
        LOG = LoggerFactory.getLogger("Subscriber[" + Thread.currentThread().getName() + "]");

        try (PubSub c = new PubSub("0.0.0.0", 20000)) {
            Subscription subscription = new Subscription("clientIdHash2", "subId3");

            //this line can throw exception if we provide value of invalid type. Check ValueType for allowed values
            subscription.add(new Rule("price", price, RuleType.LE));
            subscription.add(Rule.intRule("quality", quality, RuleType.GE));

            c.subscribe(subscription, new Callback() {
                @Override
                public void onMessage(Message message) {
                    StringBuilder sb = new StringBuilder();
                    for (Map.Entry<String, Object> entry : message.entrySet()) {
                        String key = entry.getKey() != null ? entry.getKey() : "";
                        String value = entry.getValue() != null ? entry.getValue().toString() : "";

                        sb.append(key).append("=").append(value).append(", ");
                    }

                    LOG.info("Received {}", sb.toString());
                }
            });

            LOG.info("Starting, looking for price <= {}, quality >= {}", price, quality);
            while (true) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    break;
                }
            }
        } catch (PubSubException ex) {
            LOG.warn("Could not subscribe, got error: {}", ex.getMessage());
        }

        LOG.info("Finishing");
    }
}