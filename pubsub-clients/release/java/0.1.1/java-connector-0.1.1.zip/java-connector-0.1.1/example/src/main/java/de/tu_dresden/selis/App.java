package de.tu_dresden.selis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;

public class App {
    public static void main(String[] args) throws InterruptedException {
        Logger LOG = LoggerFactory.getLogger(App.class);
        LOG.info("Starting Pub/Sub simulation");

        Thread subscriber = new Thread(new Subscriber(30, 100), "subscriber1");
        subscriber.start();

        Thread publisher1 = new Thread(new Publisher(150), "publisher1");
        publisher1.start();

        Thread publisher2 = new Thread(new Publisher(100), "publisher2");
        publisher2.start();

        Thread publisher3 = new Thread(new Publisher(800), "publisher3");
        publisher3.start();

        publisher1.join();
        publisher2.join();
        publisher3.join();
        subscriber.interrupt();
    }
}
