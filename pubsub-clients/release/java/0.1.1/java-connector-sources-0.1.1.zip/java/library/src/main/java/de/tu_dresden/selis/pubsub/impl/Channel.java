package de.tu_dresden.selis.pubsub.impl;

import com.google.gson.Gson;
import de.tu_dresden.selis.pubsub.PubSubArgumentException;
import de.tu_dresden.selis.pubsub.PubSubConnectionException;
import de.tu_dresden.selis.pubsub.PubSubException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public abstract class Channel {

    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String CONTENT_TYPE_HEADER = "Content-Type";
    public static final String HTTP_METHOD_POST = "POST";

    protected String serverEndpoint;

    protected Gson gson = new Gson();

    private Logger LOG;

    public Channel(String hostname, int portNumber) {
        LOG = LoggerFactory.getLogger(Channel.class);
        this.serverEndpoint = "http://" + hostname + ":" + portNumber;
    }

    protected <T> T post(String path, Object message) throws PubSubException {
        return post(path, message, null);
    }

    protected <T> T post(String path, Object message, Class<T> clazz) throws PubSubException {
        HttpURLConnection connection = null;
        OutputStream connectionOutputStream = null;
        BufferedReader connectionReader = null;

        URL url = getUrl(path);

        String json = gson.toJson(message);
        if (LOG.isTraceEnabled()) {
            LOG.trace("Sending message: {} as JSON to Endpoint: {}", json, url);
        }

        StringBuilder output = new StringBuilder();
        try {
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod(HTTP_METHOD_POST);
            connection.setRequestProperty(CONTENT_TYPE_HEADER, CONTENT_TYPE_JSON);

            connectionOutputStream = connection.getOutputStream();
            connectionOutputStream.write(json.getBytes());
            connectionOutputStream.flush();

            if (connection.getResponseCode() < 200 || connection.getResponseCode() > 299) {
                throw new PubSubConnectionException("Server " + url + " return error. HTTP error code: " + connection.getResponseCode() + ", message: " + connection.getResponseMessage());
            }

            connectionReader = new BufferedReader(new InputStreamReader((connection.getInputStream())));
            String line;
            while ((line = connectionReader.readLine()) != null) {
                output.append(line);
            }
        } catch (IOException e) {
            throw new PubSubConnectionException(e);
        } finally {
            if (connectionOutputStream != null) {
                try {
                    connectionOutputStream.close();
                } catch (IOException e) {
                    LOG.warn("Could not close output stream to the server connection: " + url);
                }
            }

            if (connectionReader != null) {
                try {
                    connectionReader.close();
                } catch (IOException e) {
                    LOG.warn("Could not close input stream to the server connection: " + url);
                }
            }

            if (connection != null) {
                connection.disconnect();
            }
        }

        String jsonOutput = output.toString();
        if (clazz != null && !jsonOutput.isEmpty()) {
            return gson.fromJson(jsonOutput, clazz);
        }

        return null;
    }

    private URL getUrl(String path) {
        String endpoint = serverEndpoint + path;
        try {
            return new URL(endpoint);
        } catch (MalformedURLException e) {
            throw new PubSubArgumentException("Pub/Sub address is not a valid URL: " + endpoint);
        }
    }

    public void close() {
    }

}
