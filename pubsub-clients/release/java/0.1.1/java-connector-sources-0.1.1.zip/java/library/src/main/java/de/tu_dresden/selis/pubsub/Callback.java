package de.tu_dresden.selis.pubsub;

public interface Callback {

    void onMessage(Message message);

}
