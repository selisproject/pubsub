#!/bin/bash

cd example && mvn clean install && java -jar target/client-example-0.2.0-jar-with-dependencies.jar

